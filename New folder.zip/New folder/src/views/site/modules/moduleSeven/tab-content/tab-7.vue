<template>
  <div class="tab_content">
    <div class="tab_content-text">
      <strong class="strongColor">Неоставление без помощи:</strong> из
      соображений равного нравственного уважения и обязанности оказывать помощь
      следует, что ни один человек, нуждающийся в медицинской помощи, не должен
      быть оставлен без внимания. Оказание помощи распространяется на семью и
      других лиц, близких к пациентам; следует изыскивать возможности для
      коммуникации с ними.
    </div>
    <div class="tab_content-text">
      Всем пациентам с дыхательной недостаточностью, с отсутствием показаний для
      ИВЛ или у которых она была прекращена, следует оказывать паллиативную
      помощь.
    </div>
    <div class="d-flex flex-column align-items-center my-3">
      <div class="tabImg">
        <img src="/images/tabImg/image 183.png" alt="" />
      </div>
      <div class="tab_content-block mt-3">
        <div class="tab_content-title text-center">
          Каждый человек одинаково ценен
        </div>
        <div class="tab_content-text bgTab text-center">
          Решения о лечении должны основываться на медицинских потребностях, без
          учета таких признаков, как этническая принадлежность, религия, пол,
          возраст, инвалидность или политическая ориентация
        </div>
      </div>
    </div>
    <div class="d-flex flex-column align-items-center my-3">
      <div class="tabImg">
        <img src="/images/tabImg/image 184.png" alt="" />
      </div>
      <div class="tab_content-block mt-3">
        <div
          class="tab_content-text text-center"
          style="max-width: 600px; width: 100%"
        >
          <strong class="strongColor">
            Каждый пациент имеет право получать наилучшую помощь и лечение,
            доступные в данных обстоятельствах
          </strong>
        </div>
      </div>
    </div>
    <div class="d-flex flex-column align-items-center my-3">
      <div class="tabImg">
        <img src="/images/tabImg/image 185.png" alt="" />
      </div>
      <div class="tab_content-block mt-3">
        <div
          class="tab_content-text text-center"
          style="max-width: 600px; width: 100%"
        >
          <strong class="strongColor">
            Ни один человек, нуждающийся в медицинской помощи, не должен быть
            оставлен без внимания
          </strong>
        </div>
      </div>
    </div>
    <div class="d-flex flex-column align-items-center my-3">
      <div class="tabImg">
        <img src="/images/tabImg/image 186.png" alt="" />
      </div>
      <div class="tab_content-block mt-3">
        <div
          class="tab_content-text text-center"
          style="max-width: 600px; width: 100%"
        >
          <strong class="strongColor">
            Вся коммуникация между пациентом и врачом должна оставаться
            конфиденциальной.
          </strong>
        </div>
      </div>
    </div>
    <div class="d-flex flex-column align-items-center my-3">
      <div class="tabImg">
        <img src="/images/tabImg/image 187.png" alt="" />
      </div>
      <div class="tab_content-block mt-3">
        <div
          class="tab_content-text text-center"
          style="max-width: 600px; width: 100%"
        >
          <strong class="strongColor">
            Вся коммуникация между пациентом и врачом должна оставаться
            конфиденциальной.
          </strong>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import "@/assets/styles/pages/detailed-tab.css";
export default {
  name: "tab-7",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped>
.tab_content-text {
  margin-bottom: 10px;
}
.tabImg {
  max-width: 125px;
  width: 100%;
}
.tabImg img {
  width: 100%;
  object-fit: contain;
}
</style>
