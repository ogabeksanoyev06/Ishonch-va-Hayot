<template>
  <div class="tab_content">
  
  </div>
</template>
<script>
export default {
  name: "tab-5",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped>
.tab_content-text {
  margin-bottom: 10px;
}
.tabImg {
  
  width: 100%;
  margin: 30px auto;
}
.tabImg img {
  width: 100%;
  object-fit: contain;
}
</style>
