<template>
  <div class="tab_content">
    <div class="tab_content-block">
      <div class="tab_content-title">
        Законы РУз, регулирующие права пациентов и населения:
      </div>
      <div class="tab_content-text">
        • Статья 24 «Закона об Охране Здоровья Граждан». Права пациента
        сохранение в тайне информации о факте обращения за медицинской помощью,
        о состоянии здоровья, диагнозе и иных сведений, полученных при его
        обследовании и лечении.
      </div>
      <div class="tab_content-text">
        • Закон Республики Узбекистан «О Персональных данных» Статья 27.
        Гарантии защиты персональных данных; Статья 28. Конфиденциальность
        персональных данных.
      </div>
      <div class="tab_content-text">
        • Закон Республики Узбекистан «О Принципах и Гарантиях Свободы
        Информации» Статья 11. Защита информации.
      </div>
      <div class="tab_content-text">
        • Неприкосновенность частной жизни защитили законом в Узбекистане.
        Согласно статье 46 Кодекса об административной ответственности,
        незаконное собирание или распространение сведений о частной жизни лица,
        составляющих его личную или семейную тайну, без его согласия.
      </div>
    </div>
  </div>
</template>
<script>
import "@/assets/styles/pages/detailed-tab.css";
export default {
  name: "tab-6",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped>
.tab_content-text {
  margin-bottom: 10px;
}
.tabImg {
  max-width: 430px;
  width: 100%;
  margin: 30px auto;
}
.tabImg img {
  width: 100%;
  object-fit: contain;
}
</style>
