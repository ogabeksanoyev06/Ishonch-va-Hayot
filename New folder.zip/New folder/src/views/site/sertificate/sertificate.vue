<template>
  <div></div>
</template>
<script>
export default {
  name: "sertificate-pdf",
  components: {},
  data() {
    return {};
  },
  methods: {},
};
</script>
<style scoped></style>
