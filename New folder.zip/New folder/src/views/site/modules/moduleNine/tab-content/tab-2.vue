<template>
  <div class="tab_content">
   
  </div>
</template>
<script>
import "@/assets/styles/pages/detailed-tab.css";
export default {
  name: "tab-2",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped>
.tabImg {
 
  width: 100%;
  margin: 0 auto;
  margin-top: 20px;
}
.tabImg img {
  width: 100%;
  object-fit: contain;
}
@media (max-width: 768px) {
}
</style>
